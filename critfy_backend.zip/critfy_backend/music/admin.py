from django.contrib import admin
from .models import Album, Comment, Music, Rating

@admin.register(Album)
class AlbumAdmin(admin.ModelAdmin):
    list_display = ['name', 'artist', 'release_date', 'cover_image']  # Exibe os campos no admin
    list_filter = ['artist', 'release_date']  # Filtros laterais
    search_fields = ['name', 'artist']  # Campo de busca

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['album', 'text', 'created_at']  # Exibe os campos no admin
    list_filter = ['album', 'created_at']  # Filtros laterais
    search_fields = ['text']  # Campo de busca

@admin.register(Music)
class MusicAdmin(admin.ModelAdmin):
    list_display = ['title', 'album', 'duration']  # Exibe os campos no admin
    list_filter = ['album']  # Filtros laterais
    search_fields = ['title']  # Campo de busca

@admin.register(Rating)
class RatingAdmin(admin.ModelAdmin):
    list_display = ['album', 'value']  # Exibe os campos no admin
    list_filter = ['album']  # Filtros laterais
    search_fields = ['album__name']  # Campo de busca no nome do álbum
